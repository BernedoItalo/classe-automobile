﻿using System;

namespace classeautomobile
{

  
    /////////////////////////////////////////CLASSE AUTOMOBILE
   
    internal class Automobile
    {
        private int potenza = 0;
        private string modello = "";
        private int marcia = 0;
        private int motore = 0;
        private int velocita = 0;

/////////////////////////////////// Costruttore
        public Automobile()
        {
            potenza = 0;
            modello = "";
            marcia = 0;
            motore = 0;
            velocita = 0;
        }

 ////////////////////////////////// Metodi get e set per potenza
        public int GetPotenza()
        {
            return potenza;
        }

        public void SetPotenza(int potenza)
        {
            this.potenza = potenza;
        }

//////////////////////////////////// Metodi get e set per modello
        public string GetModello()
        {
            return modello;
        }

        public void SetModello(string modello)
        {
            this.modello = modello;
        }

/////////////////////////////////// Metodi get e set per marcia
        public int GetMarcia()
        {
            return marcia;
        }

        public void SetMarcia(int marcia)
        {
            this.marcia = marcia;
        }

/////////////////////////////////// Metodi get e set per motore
        public int GetMotore()
        {
            return motore;
        }

        public void SetMotore(int motore)
        {
            this.motore = motore;
        }

///////////////////////////////// Metodi get e set per velocita
        public int GetVelocita()
        {
            return velocita;
        }

        public void SetVelocita(int velocita)
        {
            this.velocita = velocita;
        }
    }
    
    /////////////////////////////////////fine classe
    
    


    internal class Program
    {
        static void Main(string[] args)
        {
            Automobile auto = new Automobile();

////////////////////////////////// Impostiamo i valori con i metodi set
            auto.SetPotenza(120);
            auto.SetModello("Fiat Panda");
            auto.SetMarcia(3);
            auto.SetMotore(1200);
            auto.SetVelocita(80);

            // Leggiamo i valori con i metodi get
            Console.WriteLine("Potenza " + auto.GetPotenza());
            Console.WriteLine("Modello " + auto.GetModello());
            Console.WriteLine("MarciA " + auto.GetMarcia());
            Console.WriteLine("Motore " + auto.GetMotore());
            Console.WriteLine("Velocità " + auto.GetVelocita());
        }
    }
}